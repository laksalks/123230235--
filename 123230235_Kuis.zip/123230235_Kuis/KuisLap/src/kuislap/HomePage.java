/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kuislap;

import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.*;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;

/**
 *
 * @author Lab Informatika
 */

    public class HomePage extends JFrame implements ActionListener {
    private String username;
    private JButton childBtn, teenBtn, adultBtn;
    Public HomePage (String username);
    this.username = username;
    
    setTitle("Home page");
    setSize(400, 300);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)
    setLocationRelativeTo(null):
    
    JPanel panel = new Jpanel(new GridLayout (4, 1, 10, 10))

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}
